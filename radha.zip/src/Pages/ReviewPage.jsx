// import React from "react";
// import MoreReview from "../Components/MoreReview";

// const ReviewPage = () => {
//   return (
//     <>
//       <MoreReview />
//     </>
//   );
// };

// export default ReviewPage;
